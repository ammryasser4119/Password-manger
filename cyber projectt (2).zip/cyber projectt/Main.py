import sqlite3
import os
import requests
import hashlib
import secrets
import string
import pwinput
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from argon2.low_level import hash_secret_raw, Type

# الـ Salt ثابت عشان المفتاح ميتغيرش كل مرة بنفس الماستر باسورد
SALT = b'\x14\xae\x01\x08\x12\xaf\x88\x91\xde\xcc\x11\xf2\x05\x04\x11\x10'

def init_db():
    conn = sqlite3.connect('vault.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vault (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            site TEXT NOT NULL,
            username TEXT NOT NULL,
            encrypted_password BLOB NOT NULL,
            iv BLOB NOT NULL,
            tag BLOB NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def derive_key(master_password):
    """استخدام Argon2ID لتحويل الباسورد لمفتاح 256-بت"""
    return hash_secret_raw(
        secret=master_password.encode(),
        salt=SALT,
        time_cost=3,        # عدد العمليات
        memory_cost=65536,  # استخدام الرام (64MB) لتعقيد الهجوم بالـ GPU
        parallelism=4,
        hash_len=32,
        type=Type.ID
    )

def encrypt_password(key, raw_password):
    iv = os.urandom(12)  # Nonce عشوائي لكل عملية
    aesgcm = AESGCM(key)
    # التشفير والـ Authentication في خطوة واحدة
    encrypted_data = aesgcm.encrypt(iv, raw_password.encode(), None)
    tag = encrypted_data[-16:]
    ciphertext = encrypted_data[:-16]
    return ciphertext, iv, tag

def decrypt_password(key, ciphertext, iv, tag):
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(iv, ciphertext + tag, None).decode()

def check_pwned_api(password):
    """فحص التسريبات باستخدام K-Anonymity Model"""
    sha1_password = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    first5, tail = sha1_password[:5], sha1_password[5:]
    try:
        url = f'https://api.pwnedpasswords.com/range/{first5}'
        res = requests.get(url, timeout=5)
        if res.status_code == 200:
            for line in res.text.splitlines():
                h, count = line.split(':')
                if h == tail: return count
        return 0
    except: return 0

def generate_strong_password(length=18):
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def main_menu(key):
    while True:
        print("\n" + "="*40)
        print("  SHIELD VAULT - SECURE PASSWORD MANAGER")
        print("="*40)
        print("1. ➕ Add New Credential")
        print("2. 🔑 View Stored Passwords")
        print("3. 🎲 Generate Secure Password")
        print("4. 🚪 Exit")
        choice = input("\n[>] Selection: ")

        if choice == '1':
            site = input("Site Name: ")
            user = input("Username: ")
            print("1. Manual Entry | 2. Auto-Generate")
            p_opt = input("Choice: ")
            pwd = generate_strong_password() if p_opt == '2' else input("Password: ")
            if p_opt == '2': print(f"Generated: {pwd}")
            
            leaks = check_pwned_api(pwd)
            if leaks: print(f"⚠️  ALERT: This password was leaked {leaks} times!")
            
            c, i, t = encrypt_password(key, pwd)
            conn = sqlite3.connect('vault.db')
            conn.execute('INSERT INTO vault (site,username,encrypted_password,iv,tag) VALUES (?,?,?,?,?)', (site,user,c,i,t))
            conn.commit()
            print("✅ Encrypted and Saved.")
            
        elif choice == '2':
            conn = sqlite3.connect('vault.db')
            rows = conn.execute('SELECT site, username, encrypted_password, iv, tag FROM vault').fetchall()
            print(f"\n{'SITE':<15} | {'USERNAME':<15} | {'PASSWORD'}")
            print("-" * 50)
            for r in rows:
                try:
                    p = decrypt_password(key, r[2], r[3], r[4])
                    print(f"{r[0]:<15} | {r[1]:<15} | {p}")
                except: print(f"{r[0]:<15} | {r[1]:<15} | ❌ Decryption Failed")
                
        elif choice == '3':
            print(f"\n[*] Secure Password: {generate_strong_password()}")
        elif choice == '4': break

if __name__ == "__main__":
    init_db()
    print("--- SHIELD VAULT v1.0 ---")
    
    # السطر ده هيخلي اللي بتكتبه يظهر مكانه نجوم ****
    mp = pwinput.pwinput(prompt='Enter Master Password: ', mask='*')
    
    vault_key = derive_key(mp)
    main_menu(vault_key)