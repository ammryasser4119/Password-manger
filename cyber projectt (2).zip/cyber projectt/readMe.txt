# SecureVault - Professional Password Manager

## Overview
SecureVault is a CLI-based password manager built with Python. It focuses on high-level security to store and manage credentials locally using an encrypted SQLite database. The project implements modern cryptographic standards to ensure data confidentiality and integrity.

## Key Features
* **Master Password Protection:** The master password is never stored. It uses the **Argon2id** key derivation function to generate a 256-bit encryption key.
* **Strong Encryption:** Credentials are encrypted using **AES-256-GCM** (Galois/Counter Mode), providing both encryption and data authentication.
* **Breach Check:** Integrates with the **HaveIBeenPwned API** using the **K-Anonymity** model to check if passwords have been leaked in past data breaches without exposing the password itself.
* **Password Generator:** Includes a cryptographically secure random password generator using the `secrets` module.
* **Secure Input:** Uses masked input for the master password to prevent shoulder-surfing.

## Technical Architecture
* **Language:** Python 3.13+
* **Database:** SQLite3
* **Encryption Algorithm:** AES-256-GCM
* **Key Derivation:** Argon2id
* **Libraries Used:** * `cryptography` (Encryption)
    * `argon2-cffi` (Key Derivation)
    * `requests` (API communication)
    * `pwinput` (Secure masked input)

## How to Run
1. Install the required dependencies:
   ```bash
   pip install cryptography argon2-cffi requests pwinput